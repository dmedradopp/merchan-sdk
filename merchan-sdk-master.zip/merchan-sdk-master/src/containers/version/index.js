import React from 'react'
import { View, Text, StyleSheet, Image, Linking, Button } from 'react-native'
import { connect } from 'react-redux';
import { Theme } from 'sottelli-mobile-sdk'
import VersionService from '../../api-services/version-service'

class screenIncorrectVersion extends React.Component {
    
    constructor(props) {
        super(props);
        this.state = {
            version: '',
            emailSupport: ''
        };

        //this.getCurrentVersion();
    }

    getCurrentVersion() {
        /*new VersionService().getCurrentVersionAsync().then((result) => {
            if(VersionJSON.buildNumber != result.currentPageOrderedEntries[0][1]) {
                this.setState({ emailSupport: result.currentPageOrderedEntries[0][2], version: result.currentPageOrderedEntries[0][1] });
            }
            else {
                this.props.navigation.navigate({ routeName: 'MenuScreens'});
            }
        });*/
    }

    render() {
        return(
            <View style={styles.container}>
                <View style={styles.card}>
                    <Image source={require('../../images/alert.png')} />
                    <Text style={styles.title}>Aplicação Desatualizada</Text>
                    <Text style={styles.description}>Sua aplicação possuí uma nova versão disponível, favor procurar seu administrador para atualização.</Text>
                    <Text style={styles.version}>Instalada: {VersionJSON.buildNumber}</Text>
                    <Text style={styles.version}>Atual: {this.state.version}</Text>
                    <Button style={styles.button} color="red" title="Avisar Administrador" onPress={() => Linking.openURL('mailto:' + this.state.emailSupport + '?subject=Atualização do PetForce&body=Favor providenciar a atualização de meu aplicativo! Estou na versão: ' + VersionJSON.buildNumber)} />
                </View>
            </View>
        )
    }
}

const styles = StyleSheet.create({
    container: { 
        flex: 1, 
        alignItems: 'center', 
        justifyContent: 'center', 
        backgroundColor: Theme.Colors.primary,
        paddingLeft: 10,
        paddingRight: 10
    },
    card: {
        flexDirection: 'column',
        alignItems: 'center', 
        justifyContent: 'center', 
        backgroundColor: 'white',
        borderRadius: 10,
        margin: 5,
        padding: 10,
        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 2,
        },
        shadowOpacity: 0.25,
        elevation: 5
    },
    title: {
        fontSize: 25,
        color: 'red',
        paddingBottom: 20,
        paddingTop: 20
    },
    description: {
        fontSize: 15,
        color: '#000',
        paddingBottom: 10,
    },
    version: {
        fontSize: 20,
        paddingBottom: 10
    },
    button: {
        
    }
});

const mapStateToProps = store => ({
    
});

const mapDispatchToProps = {};

export default connect(mapStateToProps, mapDispatchToProps)(screenIncorrectVersion)