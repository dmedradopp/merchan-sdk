import * as Sentry from '@sentry/react-native';

export function register(token) {
    const environment = __DEV__ ? 'Development' : 'Production';
    
    Sentry.init({ 
        environment: environment,
        dsn: token, 
    });
}

export function captureException(err) {
    Sentry.captureException(err);
}

export function get() {
    return Sentry;
}

export function setInfo(id, username, email) {
    Sentry.configureScope(function(scope) {
        scope.setUser({ id, email, username });
    });
}