import React from 'react'
import { View, Image, StyleSheet } from 'react-native'
import { defineAction } from 'redux-define'
import { createAction } from 'redux-actions'
import { takeLatest, all, fork, call, put } from 'redux-saga/effects'
import { delay } from 'redux-saga'
import { syncAllData } from '../../api-services/root-sync-service'
import { userLoading } from '../../application/user/user-saga'
import { recordTypeLoading } from '../../application/record-type/record-type-saga'
import { APP_RESUME, SYNCHRONIZATION_LOADING, SYNCHRONIZATION_BASE, SYNCHRONIZATION_START_SYNC } from '../../application/sync/sync-reducer'
import { synchronizationBaseEnd } from '../../application/sync/sync-reducer'
import { store } from '../../application'

const styles = StyleSheet.create({
  containerStyle: { backgroundColor: 'white', flex: 1, flexDirection: 'column', justifyContent: 'center', alignItems: 'center' }, imageStyle: { backgroundColor: 'white' }
})

const SplashContainer = ({ navigation, banner }) => (
  <View style={styles.containerStyle}>
    <Image style={styles.imageStyle} source={require('./images/logo-premier-pet.png')} />
  </View>
);

export default SplashContainer

export const PROGRESS = defineAction('PROGRESS', ['START', 'STOP'], 'PROGRESSO DA SINCRONIZAÇÃO')

const startProgress = createAction(PROGRESS.START)
const StopProgress = createAction(PROGRESS.STOP)

function* onSynchronizationStart() {
  yield call(delay, 2000)
  yield put(startProgress())
  yield call(syncAllData)
  yield takeLatest(SYNCHRONIZATION_LOADING.END, onSynchronizationEnd)
}

function* loadBaseInformations() {
  yield call(userLoading)
  yield call(recordTypeLoading)
}

function* onSynchronizationEnd() {
  yield put(StopProgress())
}

export function* splashSagas() {
  //yield fork(onSynchronizationStart)
  yield all([
    takeLatest(SYNCHRONIZATION_START_SYNC.START, onSynchronizationStart),
    takeLatest(SYNCHRONIZATION_BASE.END, loadBaseInformations)
  ]);
}