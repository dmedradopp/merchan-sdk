import React from 'react';
import { View, Text, ScrollView } from 'react-native';
import { connect } from 'react-redux';
import { Icon, Button } from 'react-native-elements'
import * as Progress from 'react-native-progress';
import KeepAwake from 'react-native-keep-awake';
import { synchronizationLoadingCancel } from '../../application/sync/sync-reducer'
import { store, Theme } from '../../application'

class screenSynchronizationProgress extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            isVisible: false,
        };
    }

    componentDidMount() {
        requestAnimationFrame(() => {
            this.setState({
                isVisible: true,
            });
        });
    }

    render() {
        const { synchronizationProgress, synchronizationStatus, buttonCancelVisibility } = this.props
        return (    
            <View style={{flex: 1}}>
                <View style={{ flex: 1, backgroundColor: 'white', flexDirection: 'column', justifyContent: 'center', alignItems: 'center' }}>
                    { 
                        this.state.isVisible 
                        ? 
                        <Progress.Circle color={Theme.Colors.primaryDark} fill={'white'} size={120} progress={synchronizationProgress} borderWidth={0} showsText={true} thickness={7} /> 
                        : 
                        <View></View> 
                    }
                    <Text style={{color: Theme.Colors.primaryLight}}>{synchronizationStatus}</Text>

                    { buttonCancelVisibility ? 
                        <View>
                            <Button iconLeft title='Cancelar a sincronização' icon={ <Icon name='cancel' color='#FFFFFF' /> }
                                buttonStyle={{ backgroundColor: Theme.Colors.primaryDark, padding: 5, marginTop: 10, marginBottom: 5 }}
                                onPress={async () => { store.dispatch(synchronizationLoadingCancel()) }} />
                        </View>
                    :
                        <View></View>
                    }
                    <KeepAwake />
                </View>                
            </View>
        )
    }

}

const mapStateToProps = store => ({
    synchronizationProgress : store.synchronizationService.progress,
    synchronizationStatus : store.synchronizationService.status,
    buttonCancelVisibility : store.synchronizationService.buttonCancelVisibility
});

const mapDispatchToProps = {};

export default connect(mapStateToProps, mapDispatchToProps)(screenSynchronizationProgress)