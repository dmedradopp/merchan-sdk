import React from 'react';
import { View, Text, ScrollView, Image, Alert, AsyncStorage } from 'react-native';
import { connect } from 'react-redux';
import { oauth } from 'react-native-force'
import { ListItem, Icon } from 'react-native-elements';
import SafeAreaView from 'react-native-safe-area-view'
import DrawerItems from './drawer-items';
import TouchableItem from './touchable-item'
import { Theme } from '../../application'
import { persistor } from './../../application'

class DrawerContent extends React.Component {

    confirmLogout = () => {
        Alert.alert(
            'PetForce',
            'Confirma o Logout?',
            [
                {
                    text: 'Não',
                }
                ,
                {
                    text: 'Sim',
                    onPress: async () => {
                        //await persistor.purge();
                        await AsyncStorage.removeItem('dateLastSynchronization');
                        oauth.logout();
                    }
                }
            ]
        );
    }

    render() {

        const { userName, version } = this.props;

        return (    
            <ScrollView>
                <ListItem {... Theme.MenuSottelli.ListItemTopProps } title={userName} />

                <View style={{ position: 'absolute', top: 0, right: 0, paddingTop: 75, paddingRight: 5 }}>
                    <Text style={{ color: 'white' }}>v{version}</Text>
                </View>

                <DrawerItems {...this.props} />

                <TouchableItem onPress={() => { this.confirmLogout(); }} delayPressIn={0} >
                    <SafeAreaView style={{ backgroundColor : 'transparent' }} >
                        <View style={ { flexDirection : 'row', paddingLeft: 16, alignItems: 'center'}}>
                            <Icon name='exit-to-app' color={Theme.Colors.primaryDark} />
                            <Text style={{ margin: 16, color: Theme.Colors.primaryDark, paddingLeft: 15, fontWeight: 'bold',}} >
                                Logout
                            </Text>
                        </View>
                    </SafeAreaView>
                </TouchableItem>

                <View style={ Theme.MenuSottelli.BottomViewStyle } >
                    <Image style={ Theme.MenuSottelli.LogoClientImage.Style } source={ Theme.MenuSottelli.LogoClientImage.Source } />
                </View>
            </ScrollView>
        )
    }
}

const mapStateToProps = store => ({
  userName: store.user.UserName,
  userEmail: store.user.UserEmail,
  version: store.user.Version
});

const mapDispatchToProps = {};

export default connect(mapStateToProps, mapDispatchToProps)(DrawerContent)