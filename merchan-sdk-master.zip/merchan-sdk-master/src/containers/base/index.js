import React from 'react'
import { View, Image, StyleSheet } from 'react-native'
import * as Progress from 'react-native-progress';
import { store } from '../../application'

const styles = StyleSheet.create({
    containerStyle: { backgroundColor: 'white', flex: 1, flexDirection: 'column', justifyContent: 'center', alignItems: 'center' }, imageStyle: { backgroundColor: 'white' }
})

const BaseContainer = ({ navigation, banner }) => {
    const state = store.getState();

    if (state.synchronizationService.lastSync) {
        return (
            <View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
                <Progress.Circle size={30} indeterminate={true} />
            </View>
        )
    }
    else {
        return (
            <View style={styles.containerStyle}>
                <Image style={styles.imageStyle} source={require('./../splash/images/logo-premier-pet.png')} />
            </View>
        )
    }
};

export default BaseContainer;