import { oauth } from 'react-native-force'
import { call, put } from 'redux-saga/effects'
import { userLoadingStart, userLoadingFinish } from './user-reducer'
import { UserService } from '../../application'
import DeviceInfo from 'react-native-device-info'
import { setInfo } from '../../containers/issue-tracker'

export function* userLoading() {
    yield put(userLoadingStart())
    const authData = yield call(getAuthCredentials)

    const user = yield call(UserGetById, authData.userId)
    
    const userInfo = {
        UserName: user.Name,
        UserEmail: user.Email,
        UserId: authData.userId, 
        UserProfile: user.ProfileName__c,
        Version: DeviceInfo.getVersion()
    }

    setInfo(authData.userId, user.Name, user.Email);

    yield put(userLoadingFinish(userInfo))
}

function getAuthCredentials() {
    return new Promise((fulfilled, rejected) => { 
        oauth.getAuthCredentials(fulfilled, (ex) => {
            rejected(`Erro ao recuperar informações do Usuário! - ${ex}`) })
    })
}

function UserGetById(id) {
    return UserService.getById(id)
}