import { defineAction } from 'redux-define'
import { createAction } from 'redux-actions'
import { oauth } from 'react-native-force'
import { store } from '../../application'
import { REHYDRATE } from 'redux-persist';

const LOADING_USER_INFOS = defineAction('LOADING_USER_INFOS', ['START', 'FINISH'], 'CARREGAMENTO DAS INFORMAÇÕES DO USUÁRIO')

export const userLoadingStart = createAction(LOADING_USER_INFOS.START)
export const userLoadingFinish = createAction(LOADING_USER_INFOS.FINISH)

const initialState = {
  UserName: 'Não definido',
  UserEmail: 'Não definido',
  UserId: 'Não definido',
  UserProfile: 'Não definido',
  Version: ''
}

export default function userReducer(state = initialState, action) {
  switch (action.type) {
    case LOADING_USER_INFOS.FINISH:
      return {
        UserName: action.payload.UserName,
        UserEmail: action.payload.UserEmail,
        UserId: action.payload.UserId,
        UserProfile: action.payload.UserProfile,
        Version: action.payload.Version
      }
    default:
      return state;
  }
}