export default themeProps = 
{
    Colors : {
        primary: '#f26522',
        primaryLight: '#ff9651',
        primaryDark : '#f26522',
        background: '#ffffff',
        surface: '#dddcd4',
        error: '#300000',
        onPrimary : '#ffffff',
        onBackground: '#000000',
        onSurface: '#000000',
        onError: '#dddcd4',
        green: '#00441f',
        blue: '#004a80',
        black: '#000000',
        gray: '#938884',
        lightGray: '#dddcd4',
        orange: '#f58220',

        //although I don't like it, i need to insert these two lines below in order to application do not get broke
        secondaryLight: '#ff9651',
        secondaryDark : '#f26522'
    },
    /*All the properties bellow need a validation to check if is in premier style or not
        Please move the property up when updating.*/
    ButtonAdd : { 
        Icon : 'add-circle',
        Color : '#3d4db7',
        Props : {}
    }, 
    ButtonCancel : { 
        Icon : 'cancel',
        Color : '#ff5606',
        Props : {}
    },
    ButtonDelete : { 
        Icon : 'delete',
        Color : '#fa0000',
        Props : {}
    }, 
    ButtonEdit : { 
        Icon : 'create',
        Color : '#00a7f7',
        Props : {}
    }, 
    ButtonMenu : { 
        Icon : 'menu',
        Color : 'white',
        Props : {}
    }, 
    ButtonOk : { 
        Icon : 'check-circle',
        Color : '#89c440',
        Props : {}
    }, 
    ButtonSearch : { 
        Icon : 'search',
        Color : '#00bbd6',
        Props : {}
    }, 
    ButtonSync : { 
        Icon : 'sync',
        Color : '#E65100',
        Props : {}
    }, 
    ButtonText : { 

        Props: {}
    },
    InputText : {
        Shake : true,
        ContainerStyle : {
            margin: 10,
            height: 45
        },
        Type : 'text',
        InputStyle : {
            fontSize: 14
        },
        ErrorStyle : {
            color: 'red'
        },
        Placeholder : "Digite uma palavra",
        LabelStyle : {},
        Props : {}
    },
    InputTextArea : {
        //Editable : true,
        Multiline : true,
        Type : 'text',
        ContainerStyle : {
            margin: 10,
        },
        InputStyle : {
            fontSize: 14
        },
        ErrorStyle : {
            color: 'red'
        },
        Placeholder : "Digite uma mensagem",
        LabelStyle : {},
        Props : {}
    },
    InputNumber : {
        Shake : true,
        ContainerStyle : {
            margin: 10
        },
        KeyboardType : 'numeric',
        InputStyle : {
            fontSize: 14
        },
        ErrorStyle : {
            color: 'red'
        },
        Placeholder : "Digite um número",
        LabelStyle : {},
        Props : {}
    },
    InputDecimal : {
        ContainerStyle : {
            margin: 10
        },
        KeyboardType : 'numeric',
        Placeholder : "Digite um número decimal",
        InputStyle : {
            fontSize: 14
        },
        Props : {}
    },
    InputMask : {
        ContainerStyle : {
            margin: 10
        },
        Placeholder : "Digite um texto",
    },
    InputDate : {
        Shake : true,
        ContainerStyle : {
            margin: 10
        },
        Type : 'text',
        InputStyle : {
            fontSize: 14
        },
        ErrorStyle : {
            color: 'red'
        },
        Placeholder : "Selecione uma data",
        LabelStyle : {},
        Props : {}
    },
    InputImage : {
        Icon : 'photo',
        Color : '#00a7f7'
    },
    InputSwitch : {
        ActiveBackgroundColor : '#9cff57',
        ActiveButtonColor : '#64dd17',
        ActiveButtonPressedColor : '#1faa00',
        InactiveBackgroundColor : '#ff9651',
        InactiveButtonColor : '#f26522',
        InactiveButtonPressedColor : '#b83400'
    },
    inputBoolean : {
        Title : 'Checkbox'
    },
    ListCommonItem : {
        TitleStyle : {
            color: 'black',
            fontWeight: 'bold',
        },
        ContainerStyle : {
            marginBottom: 20
        }
    },
    SelectOptions : {
        UniqueKey : 'id',
        SelectText : "Selecionar itens",
        SearchInputPlaceholderText : "Procurar itens...",
        TagRemoveIconColor : "#CCC",
        TagBorderColor : "#CCC",
        TagTextColor : "#CCC",
        SelectedItemTextColor : "#CCC",
        SelectedItemIconColor : "#CCC",
        ItemTextColor : "#000",
        DisplayKey : "name",
        SearchInputStyle : { 
            color: '#CCC'
        }
    },
    SelectMultipleOptions : {
        UniqueKey : 'id',
        SelectText : "Selecionar itens",
        SearchInputPlaceholderText : "Procurar itens...",
        TagRemoveIconColor : "#CCC",
        TagBorderColor : "#CCC",
        TagTextColor : "#CCC",
        SelectedItemTextColor : "#CCC",
        SelectedItemIconColor : "#CCC",
        ItemTextColor : "#000",
        DisplayKey : "name",
        SearchInputStyle : { 
            color: '#CCC'
        }
    },
    Header : {
        IconColor : '#fff',
        TitleColor : '#fff',
        TitlePlacement: 'center',
        OuterContainerStyles : {
            backgroundColor: '#f26522'
        },
        InnerContainerStyles : {}
    },
    HeaderSave : {
        CancelStyle : { 
            backgroundColor: "#b83400", 
            borderColor: "transparent", 
            borderRadius: 5,
        },
        SaveStyle : {
            backgroundColor: "#f26522",
            borderColor: "transparent",
            borderRadius: 5,
        }
    },
    MenuSottelli : { 
        ListItemTopProps : { 
            containerStyle: { 
                backgroundColor : '#f26522'
            },
            leftIcon: {
                name: 'person', 
                /*color : 'white',*/
                rounded : true, 
                reverse : true, 
                /*size : 15 */
            },
            titleStyle : { 
                color : 'white'
            },
            //bottomDivider : true
        },
        LogoImage : { 
            Style : {
                resizeMode:'stretch',
                width: 130,
                height: 50
            },
            Source : require('../containers/splash/images/logo.png')
        },
        LogoClientImage : { 
            Style : {
                resizeMode:'stretch',
                width: 130,
                height: 50
            },
            Source : require('../containers/splash/images/logo-premier-pet.png')
        },
        BottomViewStyle : { 
            backgroundColor: 'white',
            height: 45,
            alignItems: 'center',
            justifyContent: 'center'            
        },        
    },
    ModalAlert : {
        TitleColor : "#000000",
        ColorActionText : "#000000",
        BackgroundColor : "#ffe521",
        ColorText : '#000000'
    },
    ModalError : {
        TitleColor : "#000000",
        ColorActionText : "#000000",
        BackgroundColor : "#f26522",
        ColorText : '#000000'
    },
    ModalInformation : {
        TitleColor : "#000000",
        ColorActionText : "#000000",
        BackgroundColor : "#ffe521",
        ColorText : '#000000'
    },
    ModalLoading : {
        TitleColor : "#000000",
        ColorActionText : "#000000",
        BackgroundColor : "#FFC107",
        ColorText : '#000000'
    },
    ModalQuestion : {
        TitleColor : "#43b6cd",
        ColorActionText : "#43b6cd",
        BackgroundColor : "#7e3d72",
        ColorText : '#43b6cd'
    }
};