export default themeProps = 
{
    ButtonAdd : { 
        Icon : 'add-circle',
        Color : '#3d4db7',
        Props : {}
    }, 
    ButtonCancel : { 
        Icon : 'cancel',
        Color : '#ff5606',
        Props : {}
    },
    ButtonDelete : { 
        Icon : 'delete',
        Color : '#fa0000',
        Props : {}
    }, 
    ButtonEdit : { 
        Icon : 'create',
        Color : '#00a7f7',
        Props : {}
    }, 
    ButtonMenu : { 
        Icon : 'menu',
        Color : 'white',
        Props : {}
    }, 
    ButtonOk : { 
        Icon : 'check-circle',
        Color : '#89c440',
        Props : {}
    }, 
    ButtonSearch : { 
        Icon : 'search',
        Color : '#00bbd6',
        Props : {}
    }, 
    ButtonSync : { 
        Icon : 'sync',
        Color : '#E65100',
        Props : {}
    }, 
    ButtonText : { 

        Props: {}
    },
    InputText : {
        Shake : true,
        ContainerStyle : {
            margin: 10,
            height: 45
        },
        Type : 'text',
        InputStyle : {
            fontSize: 14
        },
        ErrorStyle : {
            color: 'red'
        },
        Placeholder : "Digite uma palavra",
        LabelStyle : {},
        Props : {}
    },
    InputTextArea : {
        Editable : true,
        Multiline : true,
        Type : 'text',
        ContainerStyle : {
            margin: 10,
        },
        InputStyle : {
            fontSize: 14
        },
        ErrorStyle : {
            color: 'red'
        },
        Placeholder : "Digite uma mensagem",
        LabelStyle : {},
        Props : {}
    },
    InputNumber : {
        Shake : true,
        ContainerStyle : {
            margin: 10
        },
        KeyboardType : 'numeric',
        InputStyle : {
            fontSize: 14
        },
        ErrorStyle : {
            color: 'red'
        },
        Placeholder : "Digite um número",
        LabelStyle : {},
        Props : {}
    },
    InputDecimal : {
        ContainerStyle : {
            margin: 10
        },
        KeyboardType : 'numeric',
        Placeholder : "Digite um número decimal",
        InputStyle : {
            fontSize: 14
        },
        Props : {}
    },
    InputMask : {
        ContainerStyle : {
            margin: 10
        },
        Placeholder : "Digite um texto",
    },
    InputDate : {
        Shake : true,
        ContainerStyle : {
            margin: 10
        },
        Type : 'text',
        InputStyle : {
            fontSize: 14
        },
        ErrorStyle : {
            color: 'red'
        },
        Placeholder : "Selecione uma data",
        LabelStyle : {},
        Props : {}
    },
    InputImage : {
        Icon : 'photo',
        Color : '#00a7f7'
    },
    InputSwitch : {
        ActiveBackgroundColor : '#9cff57',
        ActiveButtonColor : '#64dd17',
        ActiveButtonPressedColor : '#1faa00',
        InactiveBackgroundColor : '#ff5131',
        InactiveButtonColor : '#d50000',
        InactiveButtonPressedColor : '#9b0000'
    },
    inputBoolean : {
        Title : 'Checkbox'
    },
    Header : {
        IconColor : '#fff',
        TitleColor : '#fff',
        TitlePlacement: 'center',
        OuterContainerStyles : {
            backgroundColor: '#00985d'
        },
        InnerContainerStyles : {}
    },
    HeaderSave : {
        CancelStyle : { 
            backgroundColor: "#50ca8b", 
            borderColor: "transparent", 
            borderRadius: 5,
       },
       SaveStyle : {
            backgroundColor: "#006933",
            borderColor: "transparent",
            borderRadius: 5,
        }
    },
    ListCommonItem : {
        TitleStyle : {
            color: 'black',
            fontWeight: 'bold',
        },
        ContainerStyle : {
            marginBottom: 20
        }
    },
    SelectOptions : {
        UniqueKey : 'id',
        SelectText : "Selecionar itens",
        SearchInputPlaceholderText : "Procurar itens...",
        TagRemoveIconColor : "#CCC",
        TagBorderColor : "#CCC",
        TagTextColor : "#CCC",
        SelectedItemTextColor : "#CCC",
        SelectedItemIconColor : "#CCC",
        ItemTextColor : "#000",
        DisplayKey : "name",
        SearchInputStyle : { 
            color: '#CCC'
        }
    },
    SelectMultipleOptions : {
        UniqueKey : 'id',
        SelectText : "Selecionar itens",
        SearchInputPlaceholderText : "Procurar itens...",
        TagRemoveIconColor : "#CCC",
        TagBorderColor : "#CCC",
        TagTextColor : "#CCC",
        SelectedItemTextColor : "#CCC",
        SelectedItemIconColor : "#CCC",
        ItemTextColor : "#000",
        DisplayKey : "name",
        SearchInputStyle : { 
            color: '#CCC'
        }
    },
    Colors : {
        primaryLight: '#388E3C',
        primaryDark : '#1B5E20',
        secondaryLight: '#33691E',
        secondaryDark : '#2E7D32',
    },
    MenuSottelli : { 
        ListItemTopProps : { 
            containerStyle: { 
                backgroundColor : '#00985d'
            },
            leftIcon: {
                name: 'person', 
                /*color : 'white',*/
                rounded : true, 
                reverse : true, 
                /*size : 15 */
            },
            titleStyle : { 
                color : 'white'
            },
            bottomDivider : true
        },
        LogoImage : { 
            Style : {
                resizeMode:'stretch',
                height: 35,
                width: 137
            },
            Source : require('../containers/splash/images/logo.png')
        },
        LogoClientImage : { 
            Style : {
                resizeMode:'stretch',
                height: 35,
                width: 137
            },
            Source : require('../containers/splash/images/logo.png')
        },
        BottomViewStyle : { 
            backgroundColor: 'white',
            height: 45,
            alignItems: 'center',
            justifyContent: 'center'            
        },        
    },
    ModalAlert : {
        TitleColor : "#000000",
        ColorActionText : "#000000",
        BackgroundColor : "#ffe521",
        ColorText : '#000000'
    },
    ModalError : {
        TitleColor : "#000000",
        ColorActionText : "#000000",
        BackgroundColor : "#f44336",
        ColorText : '#000000'
    },
    ModalInformation : {
        TitleColor : "#000000",
        ColorActionText : "#000000",
        BackgroundColor : "#ffe521",
        ColorText : '#000000'
    },
    ModalLoading : {
        TitleColor : "#000000",
        ColorActionText : "#000000",
        BackgroundColor : "#FFC107",
        ColorText : '#000000'
    },
    ModalQuestion : {
        TitleColor : "#43b6cd",
        ColorActionText : "#43b6cd",
        BackgroundColor : "#7e3d72",
        ColorText : '#43b6cd'
    }
};