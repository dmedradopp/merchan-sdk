import { Theme } from '../../application'

import React, { PureComponent } from 'react';
import { StyleSheet, TouchableOpacity, View, Text } from 'react-native';
import { MaterialDialog } from 'react-native-material-dialog';
import { material } from 'react-native-typography';

export default class ModalAlert extends React.PureComponent {
    constructor(props) {
        super(props);
  
        this.state = {
            visibility: this.props.visibility ? this.props.visibility : false,
        }
    }

    render() {
        return(
            <View>
                <MaterialDialog
                    visible={this.state.visibility}
                    title={this.props.title}
                    titleColor={Theme.ModalAlert.TitleColor}
                    colorAccent={Theme.ModalAlert.ColorActionText}
                    backgroundColor={Theme.ModalAlert.BackgroundColor}
                    onCancel={() => {
                        this.setState({ visibility: false });
                    }}
                >
                    <Text style={[material.subheading, { color: Theme.ModalAlert.ColorText }]}>
                        {this.props.message}
                    </Text>
                </MaterialDialog>
            </View>
        );
    }
}