import React, { PureComponent } from 'react';
import { Theme } from '../../application'
import HeaderMaster from '../header-master'
import { Header } from 'react-native-elements'

export default class HeaderAdd extends React.Component {
    render() {
        const { title } = this.props
        return (
            <HeaderMaster title={title} rightComponent={<ButtonAdd onPress={this.props.onAddPress} />} />
        )
    }
}
