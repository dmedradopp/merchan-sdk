import React, { PureComponent } from 'react';
import { Theme } from '../../application'

import { Header } from 'react-native-elements'

class ButtonCancel extends React.Component {
    render() {
        return (
            <Button onPress={ this.props.onPress } title={ this.props.title } 
             buttonStyle={ Theme.HeaderSave.CancelStyle } />
        )
    }
}

class ButtonSave extends React.Component {
    render() {
        return (
            <Button onPress={ this.props.onPress } title={ this.props.title } 
            buttonStyle={ Theme.HeaderSave.SaveStyle } />
        )
    }
}

export default class HeaderMaster extends React.Component {
    render() {
        const { rightComponent , title } = this.props
        return (
            <Header placement={ Theme.Header.TitlePlacement }
                    outerContainerStyles = { Theme.Header.OuterContainerStyles }
                    innerContainerStyles = { Theme.Header.InnerContainerStyles }
                    
                    leftComponent={<ButtonCancel title='Cancelar' onPress={ this.props.onCancelPress } />}
                    centerComponent={{ text: title, style: { color: Theme.Header.TitleColor } }} 
                    rightComponent={<ButtonSave title='Salvar' onPress={ this.props.onSavePress } />} />
        )
    }
}
