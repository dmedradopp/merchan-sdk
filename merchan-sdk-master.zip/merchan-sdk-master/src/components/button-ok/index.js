import { Theme } from '../../application'

import React, { PureComponent } from 'react';
import { Icon } from 'react-native-elements';

export default class ButtonOk extends React.PureComponent {
    render() { 
        return (
            <Icon {...Theme.ButtonAdd.Props} onPress={ this.props.onPress } name={Theme.ButtonOk.Icon} color={Theme.ButtonOk.Color} />
        ); 
    }
}