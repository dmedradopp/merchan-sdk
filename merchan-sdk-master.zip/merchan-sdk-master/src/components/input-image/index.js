import { Theme } from '../../application'

import React, { PureComponent } from 'react';
import { Icon } from 'react-native-elements';
import ImagePicker from 'react-native-image-crop-picker';

export default class InputImage extends React.PureComponent {
    render() {
        let fnOnPress = () => {
            ImagePicker.openPicker(
            {
                width: this.props.ImageWidth,
                height: this.props.ImageHeight,
                cropping: true
            }).then(image => { this.props.onImageSelected(image) })
        }

        return(
            <Icon name={Theme.InputImage.Icon} color={Theme.InputImage.Color} onPress={ fnOnPress } />
        );
    }
}