import { Theme } from '../../application'

import React, { PureComponent } from 'react';
import { Input } from 'react-native-elements';

export default class InputNumber extends React.PureComponent {
    render() {

        let additionalProps = {};

        if (this.props.leftIcon) additionalProps.leftIcon = this.props.leftIcon;        
        
        return(
            <Input
                {...Theme.InputNumber.Props} 
                {...additionalProps}
                placeholder={ this.props.placeholder ? this.props.placeholder : Theme.InputNumber.Placeholder }
                label={this.props.label}
                labelStyle={Theme.InputNumber.LabelStyle}
                value={this.props.value}
                onChangeText={this.props.onChangeText}
                errorMessage={this.props.errorMessage}
                errorStyle={Theme.InputText.ErrorStyle}
                keyboardType={Theme.InputNumber.KeyboardType}
                shake={Theme.InputNumber.Shake} 
                containerStyle={Theme.InputNumber.ContainerStyle}
                inputStyle={Theme.InputNumber.InputStyle} 
            />
        );
    }
}