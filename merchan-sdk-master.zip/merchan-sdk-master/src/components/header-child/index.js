import React, { PureComponent } from 'react';
import { Theme } from '../../application'

import { Header } from 'react-native-elements'

export default class HeaderChild extends React.Component {
    render() {
        const { rightComponent , title } = this.props
        return (
            <Header placement={ Theme.Header.TitlePlacement }
                    outerContainerStyles = { Theme.Header.OuterContainerStyles }
                    innerContainerStyles = { Theme.Header.InnerContainerStyles }
                    
                    leftComponent={{ icon: 'keyboard-backspace', color: Theme.Header.IconColor, onPress: this.props.onBackPress }}
                    centerComponent={{ text: title, style: { color: Theme.Header.TitleColor } }} 
                    rightComponent={rightComponent} />
        )
    }
}
