import { Theme } from '../../application'

import React, { PureComponent } from 'react';
import { View, TouchableOpacity } from 'react-native';
import DateTimePicker from 'react-native-modal-datetime-picker';
import { Input } from 'react-native-elements';

export default class InputDate extends React.PureComponent {

    constructor(props) {
        super(props)

        let sel = props.value;
        let dateval = (sel) ? new Date(sel.split('/').reverse().join('-')) : null
        this.state = {
            isDateTimePickerVisible: false,
            dateSelected: sel,
            dateSelectedValue: dateval
        };        
    }


    showDateTimePicker = () => this.setState({ isDateTimePickerVisible: true });
    hideDateTimePicker = () => this.setState({ isDateTimePickerVisible: false });
    handleDatePicked = (date) => {
        this.hideDateTimePicker();

        var day = date.getDate();
        var month = date.getMonth()+1; //January is 0!

        var year = date.getFullYear();

        if(day<10){
            day='0'+day;
        } 
        if(month<10){
            month='0'+month;
        } 

        var date = day+'/'+month+'/'+year;
        let dateval = new Date(date.split('/').reverse().join('-'))

        this.setState({ dateSelected: date, dateSelectedValue : dateval });
    };

    render() {

        let additionalProps = {};
        
        if (this.state.dateSelectedValue) additionalProps.date = this.state.dateSelectedValue

        return(
            <View style={{ flex: 1 }}>
                <TouchableOpacity onPress={this.showDateTimePicker}>
                    <Input 
                        {...Theme.InputDate.Props}
                        editable={false} 
                        placeholder={ this.props.placeholder ? this.props.placeholder : Theme.InputDate.Placeholder }
                        label={this.props.label}
                        labelStyle={Theme.InputDate.LabelStyle}
                        value={this.state.dateSelected}
                        errorMessage={this.props.errorMessage}
                        errorStyle={Theme.InputDate.ErrorStyle}
                        type={Theme.InputDate.Type}
                        shake={Theme.InputDate.Shake} 
                        containerStyle={Theme.InputDate.ContainerStyle}
                        inputStyle={Theme.InputDate.InputStyle} 
                        onFocus={this.showDateTimePicker}
                    />
                </TouchableOpacity>
                <DateTimePicker {...additionalProps} isVisible={this.state.isDateTimePickerVisible} onConfirm={this.handleDatePicked}
                    onCancel={this.hideDateTimePicker} datePickerModeAndroid='calendar' />
            </View>
        );
    }
}