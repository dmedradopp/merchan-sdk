// imports necessários para o componente
import React, { Component } from 'react';
import { ListItem } from 'react-native-elements';

//Exportando a classe responsável por trazer o componente
export default class ListCommonItem extends React.PureComponent {
    render() {
        return(
            <ListItem
                {...this.props}
            />
        );
    }
}