import { Theme } from '../../application'

import React, { PureComponent } from 'react';
import { Input } from 'react-native-elements';

export default class InputText extends React.PureComponent {
    render() { 
        
        return (
            <Input 
                {...Theme.InputText.Props} 
                placeholder={ this.props.placeholder ? this.props.placeholder : Theme.InputTextArea.Placeholder }
                label={this.props.label}
                labelStyle={Theme.InputText.LabelStyle}
                value={this.props.value}
                errorMessage={this.props.errorMessage}
                errorStyle={Theme.InputText.ErrorStyle}
                editable={this.props.editable}
                onChangeText={this.props.onChangeText}
                type={Theme.InputText.Type}
                shake={Theme.InputText.Shake} 
                containerStyle={Theme.InputText.ContainerStyle}
                inputStyle={Theme.InputText.InputStyle} 
            />
        ); 
    }
}