import { Theme } from '../../application'

import React, { Component } from 'react';
import { View } from 'react-native';
import MultiSelect from 'react-native-multiple-select';

export default class SelectMultipleOptions extends React.PureComponent {
    constructor(props) {
        super(props);

        this.state = {
            selectedItems: []
        };
    }

    render() {
        
        const onSelectedItemsChange = selectedItems => {
            this.setState({ selectedItems });
        };
     
        const { selectedItems } = this.state; 
        
        return(
            <View style={{ flex: 1 }}>
                <MultiSelect
                    ref={(component) => { this.multiSelect = component }}
                    uniqueKey={ this.props.uniqueKey ? this.props.uniqueKey : Theme.SelectMultipleOptions.UniqueKey }
                    displayKey={ this.props.displayKey ? this.props.displayKey : Theme.SelectMultipleOptions.DisplayKey }
                    onChangeInput={this.props.onChangeInput}
                    items={this.props.items}
                    onSelectedItemsChange={onSelectedItemsChange}
                    selectedItems={selectedItems}
                    selectText={Theme.SelectMultipleOptions.SelectText}
                    searchInputPlaceholderText={Theme.SelectMultipleOptions.SearchInputPlaceholderText}
                    tagRemoveIconColor={Theme.SelectMultipleOptions.TagRemoveIconColor}
                    tagBorderColor={Theme.SelectMultipleOptions.TagBorderColor}
                    tagTextColor={Theme.SelectMultipleOptions.TagTextColor}
                    selectedItemTextColor={Theme.SelectMultipleOptions.SelectedItemTextColor}
                    selectedItemIconColor={Theme.SelectMultipleOptions.SelectedItemIconColor}
                    itemTextColor={Theme.SelectMultipleOptions.ItemTextColor}
                    searchInputStyle={Theme.SelectMultipleOptions.SearchInputStyle}
                />
                <View>
                    {
                        this.multiselect
                            ? 
                        this.multiSelect.getSelectedItemsExt(selectedItems)
                            :
                        null
                    }
                </View>
            </View>
        );
    }
}