import { Theme } from '../../application'

import React, { Component } from 'react';
import {
  StyleSheet,
  Text,
  View,
} from 'react-native';
import * as Progress from 'react-native-progress';

export default class ProgressBar extends React.PureComponent {
    constructor(props) {
        super(props);
    
        this.state = {
          progress: 0,
          indeterminate: true,
        };
      }
    
      componentDidMount() {
        this.animate();
      }
    
      animate() {
        let progress = 0;
        this.setState({ progress });
        setTimeout(() => {
          this.setState({ indeterminate: false });
          setInterval(() => {
            progress += Math.random() / 5;
            if (progress > 1) {
              progress = 1;
            }
            this.setState({ progress });
          }, 500);
        }, 1500);
      }
    
      render() {
        return (
          <Progress.Bar
            progress={this.state.progress}
            indeterminate={this.state.indeterminate}
          />
        );
    }
}