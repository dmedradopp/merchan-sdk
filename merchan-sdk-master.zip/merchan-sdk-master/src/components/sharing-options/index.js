// imports necessários para o componente
import React, { Component } from 'react';
import { View, TouchableHighlight, Share } from 'react-native';
import { Icon } from 'react-native-elements';

//Exportando a classe responsável por trazer o componente
export default class SharingOptions extends React.PureComponent {

    _shareTextMessage () {
        Share.share({
          message: 'Compartilhando mensagem de teste!'
        })
        .then(this._showResult)
        .catch(err => console.log(err))
    }

    _showResult (result) {
        console.log(result)
    }

    render() {
        return(
            <TouchableHighlight onPress={this._shareTextMessage}>
                <View>
                    <Icon
                        type='font-awesome'
                        name='share-alt'
                        color='#511c57'
                    />
                </View>
            </TouchableHighlight>
        );
    }
}