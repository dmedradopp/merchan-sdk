import { Theme } from '../../application'

import React, { Component } from 'react';
import { View } from 'react-native';
import MultiSelect from 'react-native-multiple-select';

export default class SelectOptions extends React.PureComponent {
    constructor(props) {
        super(props);

        this.state = {
            selectedItems: this.props.selectedItems ? [this.props.selectedItems] : []
        };
    }

    render() {
        
        const onSelectedItemsChange = selectedItems => {
            this.setState({ selectedItems });
        };
     
        const { selectedItems } = this.state;   
        
        return(
            <View style={{ marginTop: 10 }}>
                <MultiSelect
                    single
                    hideTags
                    uniqueKey={ this.props.uniqueKey ? this.props.uniqueKey : Theme.SelectOptions.UniqueKey }
                    displayKey={ this.props.displayKey ? this.props.displayKey : Theme.SelectOptions.DisplayKey }
                    onChangeInput={this.props.onChangeInput}
                    items={this.props.items}
                    onSelectedItemsChange={ this.props.onSelectedItemsChange ? this.props.onSelectedItemsChange : onSelectedItemsChange }
                    selectedItems={[this.props.selectedItems]}
                    fixedHeight={true}
                    selectText={Theme.SelectOptions.SelectText}
                    autoFocusInput={false}
                    searchInputPlaceholderText={Theme.SelectOptions.SearchInputPlaceholderText}
                    //tagRemoveIconColor={Theme.SelectOptions.TagRemoveIconColor}
                    //tagBorderColor={Theme.SelectOptions.TagBorderColor}
                    //tagTextColor={Theme.SelectOptions.TagTextColor}
                    //selectedItemTextColor={Theme.SelectOptions.SelectedItemTextColor}
                    //selectedItemIconColor={Theme.SelectOptions.SelectedItemIconColor}
                    //itemTextColor={Theme.SelectOptions.ItemTextColor}
                    searchInputStyle={Theme.SelectOptions.SearchInputStyle}
                />
            </View>
        );
    }
}