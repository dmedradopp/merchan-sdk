// imports necessários para o componente
import React, { Component } from 'react';
import { StyleSheet, TouchableOpacity, View, Text } from 'react-native';
import { material } from 'react-native-typography';
import { MessageBarManager } from 'react-native-message-bar';

//Exportando a classe responsável por trazer o componente
export default class NotificationCommon extends React.PureComponent {

    showSimpleAlert () {
        // Title or Message is at least Mandatory
        // alertType is not Mandatory, but if no alertType provided, 'info' (blue color) will picked for you
    
        // Simple show the alert with the manager
        MessageBarManager.showAlert({
          message: 'Essa é uma notificação simples',
          alertType: 'info'
        })
    }

    render() {
        
        const styles = StyleSheet.create({
            button: {
                flexDirection: 'row',
                justifyContent: 'center',
                alignItems: 'center',
                minWidth: 88,
                height: 36,
                borderRadius: 2,
                backgroundColor: '#009688',
                elevation: 2,
                paddingHorizontal: 16,
                marginTop: 16,
            },
        })
        
        return(
            <TouchableOpacity
                onPress={() => 
                    this.showSimpleAlert()
                }
            >
                <View style={styles.button}>
                    <Text style={material.button}>Exibir notificação</Text>
                </View>
            </TouchableOpacity>
        );
    }
}