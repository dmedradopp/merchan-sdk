import { Theme } from '../../application'

import React, { PureComponent } from 'react';
import { CheckBox } from 'react-native-elements';

export default class InputBoolean extends React.PureComponent {
    constructor(props) {
        super(props);
  
        this.state = {
            checked: this.props.checked ? this.props.checked : false,
        }
    }

    render() {
        return(
            <CheckBox
                title={ this.props.title ? this.props.title : Theme.InputBoolean.Title }
                checked={ this.state.checked }
                onPress={() => { 
                    this.setState({ checked: !this.state.checked })
                }}
            />
        );
    }
}