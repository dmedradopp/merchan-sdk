import { Theme } from '../../application'

import React, { PureComponent } from 'react';
import { StyleSheet, TouchableOpacity, View, Text } from 'react-native';
import { MaterialDialog } from 'react-native-material-dialog';
import { material } from 'react-native-typography';
import * as Progress from 'react-native-progress';

export default class ModalLoading extends React.PureComponent {
    constructor(props) {
        super(props);
  
        this.state = {
            visibility: this.props.visibility ? this.props.visibility : false,
            progress: this.props.progress ? this.props.progress : false,
        }
    }

    render() {

        return(
            <View>
                <MaterialDialog
                    visible={this.state.visibility}
                    title={this.props.title}
                    titleColor={Theme.ModalLoading.TitleColor}
                    colorAccent={Theme.ModalLoading.ColorActionText}
                    backgroundColor={Theme.ModalLoading.BackgroundColor}
                    onCancel={() => {
                        this.setState({ visibility: false });
                    }}
                >
                    <Progress.Circle width={200} progress={this.state.progress} />
                </MaterialDialog>
            </View>
        );
    }
}