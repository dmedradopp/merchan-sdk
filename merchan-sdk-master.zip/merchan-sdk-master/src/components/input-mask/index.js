import { Theme } from '../../application'

import React, { PureComponent } from 'react';
//import TextInputMask from 'react-native-text-input-mask';

export default class InputMask extends React.PureComponent {
/*    render() {
        return(
            <TextInputMask
                {...Theme.InputMask.Props} 
                placeholder={ this.props.placeholder ? this.props.placeholder : Theme.InputMask.Placeholder }
                refInput={ref => { this.input = ref }}
                containerStyle={Theme.InputDecimal.ContainerStyle}
                onChangeText={ this.props.onChangeText }
                value={this.props.value}
                mask={ this.props.mask }
            />
        );
    }*/
}