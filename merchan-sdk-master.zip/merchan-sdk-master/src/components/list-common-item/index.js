import { Theme } from '../../application'

import React, { PureComponent } from 'react';
import { ListItem } from 'react-native-elements';

export default class ListCommonItem extends React.PureComponent {
    render() {

        let additionalProps = {};

        if (this.props.avatar) additionalProps.leftAvatar = this.props.avatar;
        if (this.props.icon) additionalProps.leftIcon = this.props.icon;
        if (this.props.subtitle) additionalProps.subtitle = this.props.subtitle;
        if (this.props.badge) additionalProps.badge = this.props.badge;
        if (this.props.onPress) additionalProps.onPress = this.props.onPress;

        return(
            <ListItem
                {...additionalProps}
                title={this.props.title}
                titleStyle={Theme.ListCommonItem.TitleStyle}
                bottomDivider={true}
            />
        );
    }
}