import { Theme } from '../../application'

import React, { PureComponent } from 'react';
import { Icon } from 'react-native-elements';

export default class ButtonAdd extends React.PureComponent {
    render() { 
        return (
            <Icon {...Theme.ButtonAdd.Props} onPress={ this.props.onPress } name={Theme.ButtonAdd.Icon} color={Theme.ButtonAdd.Color} />
        ); 
    }
}