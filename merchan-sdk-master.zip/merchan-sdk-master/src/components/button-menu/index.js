import { Theme } from '../../application'

import React, { PureComponent } from 'react';
import { Icon } from 'react-native-elements';
import { connect } from 'react-redux';
import { defineAction } from 'redux-define';
import { createAction } from 'redux-actions';

export const MENU = defineAction('MENU', ['OPEN'], 'COMMON');

const menuOpen = createAction(MENU.OPEN);

class ButtonMenu extends React.PureComponent {
    render() { 
        const { openMenu } = this.props;
        return (
            <Icon {...Theme.ButtonAdd.Props} onPress={() => openMenu()} name={Theme.ButtonMenu.Icon} color={Theme.ButtonMenu.Color} />
        ); 
    }
}

const mapStateToProps = store => ({
});

const mapDispatchToProps = {
  openMenu: menuOpen,
};
  
export default connect(mapStateToProps, mapDispatchToProps)(ButtonMenu);
  