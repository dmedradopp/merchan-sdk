import { Theme } from '../../application'

import React, { PureComponent } from 'react';
import { StyleSheet, TouchableOpacity, View, Text } from 'react-native';
import { MaterialDialog } from 'react-native-material-dialog';
import { material } from 'react-native-typography';

export default class ModalError extends React.PureComponent {
    constructor(props) {
        super(props);
  
        this.state = {
            visibility: this.props.visibility ? this.props.visibility : false,
        }
    }

    render() {
        return(
            <View>
                <MaterialDialog
                    visible={this.state.visibility}
                    title={this.props.title}
                    titleColor={Theme.ModalError.TitleColor}
                    colorAccent={Theme.ModalError.ColorActionText}
                    backgroundColor={Theme.ModalError.BackgroundColor}
                    onCancel={() => {
                        this.setState({ visibility: false });
                    }}
                >
                    <Text style={[material.subheading, { color: Theme.ModalError.ColorText }]}>
                        {this.props.message}
                    </Text>
                </MaterialDialog>
            </View>
        );
    }
}