import React, { PureComponent } from 'react';
import { Theme } from '../../application'
import ButtonMenu from '../button-menu';
import { Header } from 'react-native-elements'

export default class HeaderMaster extends React.Component {
    render() {
        const { rightComponent , title } = this.props
        return (
            <Header placement={ Theme.Header.TitlePlacement }
                    outerContainerStyles = { Theme.Header.OuterContainerStyles }
                    innerContainerStyles = { Theme.Header.InnerContainerStyles }
                    
                    leftComponent={<ButtonMenu />} 
                    centerComponent={{ text: title, style: { color: Theme.Header.TitleColor } }} 
                    rightComponent={rightComponent} />
        )
    }
}
