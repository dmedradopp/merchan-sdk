import { Theme } from '../../application'

import React, { PureComponent } from 'react';
import { Input } from 'react-native-elements'

export default class InputTextArea extends React.PureComponent {
    render() { 
        return (
            <Input
                {...Theme.InputTextArea.Props} 
                placeholder={ this.props.placeholder ? this.props.placeholder : Theme.InputTextArea.Placeholder }
                label={this.props.label}
                labelStyle={Theme.InputTextArea.LabelStyle}
                value={this.props.value}
                errorMessage={this.props.errorMessage}
                errorStyle={Theme.InputText.ErrorStyle}
                editable={this.props.editable}
                multiline={Theme.InputTextArea.Multiline}
                onChangeText={this.props.onChangeText}
                type={Theme.InputTextArea.Type}
                shake={Theme.InputTextArea.Shake} 
                containerStyle={Theme.InputTextArea.ContainerStyle}
                inputStyle={Theme.InputTextArea.InputStyle} 
            />
        ); 
    }
}