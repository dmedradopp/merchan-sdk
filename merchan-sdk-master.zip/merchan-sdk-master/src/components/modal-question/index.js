import { Theme } from '../../application'

import React, { PureComponent } from 'react';
import { StyleSheet, TouchableOpacity, View, Text } from 'react-native';
import { MaterialDialog } from 'react-native-material-dialog';
import { material } from 'react-native-typography';

export default class ModalQuestion extends React.PureComponent {
    constructor(props) {
        super(props);
  
        this.state = {
            visibility: this.props.visibility ? this.props.visibility : false,
        }
    }

    render() {
        return(
            <View>
                <MaterialDialog
                    visible={this.state.visibility}
                    title={this.props.title}
                    titleColor={Theme.ModalQuestion.TitleColor}
                    colorAccent={Theme.ModalQuestion.ColorActionText}
                    backgroundColor={Theme.ModalQuestion.BackgroundColor}
                    okLabel={this.props.okBtnMessage}
                    onOk={() => {
                        this.setState({ visibility: false });
                    }}
                    cancelLabel={this.props.cancelBtnMessage}
                    onCancel={() => {
                        this.setState({ visibility: false });
                    }}
                >
                    <Text style={[material.subheading, { color: Theme.ModalQuestion.ColorText }]}>
                        {this.props.message}
                    </Text>
                </MaterialDialog>
            </View>
        );
    }
}