import { Theme } from '../../application'

import React, { PureComponent } from 'react';
import { Icon } from 'react-native-elements';

export default class ButtonSearch extends React.PureComponent {
    render() { 
        return (
            <Icon {...Theme.ButtonAdd.Props} onPress={ this.props.onPress } name={Theme.ButtonSearch.Icon} color={Theme.ButtonSearch.Color} />
        ); 
    }
}