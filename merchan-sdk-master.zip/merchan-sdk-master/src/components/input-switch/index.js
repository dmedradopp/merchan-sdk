// import { Theme } from '../../application'

import React, { PureComponent } from 'react';
import {View, Text } from 'react-native'
// import Switch from 'react-native-material-switch';

export default class InputSwitch extends React.PureComponent {
    render() {
        return(<View><Text>Componente não desenvolvido.</Text></View>);
            // <Switch
            //     onChangeState={this.props.onChangeState}
            //     active={this.props.active}
            //     activeBackgroundColor={Theme.InputSwitch.ActiveBackgroundColor}
            //     inactiveBackgroundColor={Theme.InputSwitch.InactiveBackgroundColor}
            //     activeButtonColor={Theme.InputSwitch.ActiveButtonColor}
            //     activeButtonPressedColor={Theme.InputSwitch.ActiveButtonPressedColor}
            //     inactiveButtonColor={Theme.InputSwitch.InactiveButtonColor}
            //     inactiveButtonPressedColor={Theme.InputSwitch.InactiveButtonPressedColor}
            // />
    }
}