import React, { PureComponent } from 'react';
import { Theme } from '../../application'
import HeaderChild from '../header-child'
import { Header, Icon } from 'react-native-elements'

export default class HeaderDetail extends React.Component {
    render() {
        const { rightComponent , title } = this.props
        return (
            <HeaderChild title={title}
                rightComponent={
                    <View style={{ flex: 1, width: 60, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center'}}>
                        <Icon name='edit' color='white' onPress={this.props.onEditPress} />
                        <Icon name='delete' color='white' onPress={this.props.onDeletePress} />
                    </View>
                }
            />
        )
    }
}
