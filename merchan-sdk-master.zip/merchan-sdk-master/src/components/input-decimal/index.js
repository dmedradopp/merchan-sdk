import { Theme } from '../../application'

import React, { PureComponent } from 'react';
//import TextInputMask from 'react-native-text-input-mask';

export default class InputDecimal extends React.PureComponent {
/*    render() {
        return(
            <TextInputMask
                {...Theme.InputDecimal.Props} 
                placeholder={ this.props.placeholder ? this.props.placeholder : Theme.InputDecimal.Placeholder }
                keyboardType={Theme.InputNumber.KeyboardType}
                refInput={ref => { this.input = ref }}
                containerStyle={Theme.InputDecimal.ContainerStyle}
                value={this.props.value}
                onChangeText={ this.props.onChangeText }
                mask={ this.props.mask }
            />
        );
    }*/
}