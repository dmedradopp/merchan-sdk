// imports necessários para o componente
import React, { Component } from 'react';
import { View } from 'react-native';

//Exportando a classe responsável por trazer o componente
export default class ListCommon extends React.PureComponent {
    render() {
        return(
            <View>
                {this.props.children}
            </View>
        );
    }
}