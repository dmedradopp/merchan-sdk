// imports necessários para o componente
import React, { Component } from 'react';
import { List } from 'react-native-elements';

//Exportando a classe responsável por trazer o componente
export default class ListCommon extends React.PureComponent {
    constructor(props) {
        super(props);
    }
    render() {
        return(
            <List containerStyle={{marginBottom: 20}}>
                {this.props.children}
            </List>
        );
    }
}